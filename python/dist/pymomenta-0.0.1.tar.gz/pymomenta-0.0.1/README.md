# PyMomenta

**Coming Soon.**

This is the future Python wrapper for **Momenta.jl**, a high-performance Dynamic Panel GMM estimator written in Julia.

Please visit the [Momenta.jl repository](https://https://github.com/dazhwu/Momenta.jl) for the core engine.